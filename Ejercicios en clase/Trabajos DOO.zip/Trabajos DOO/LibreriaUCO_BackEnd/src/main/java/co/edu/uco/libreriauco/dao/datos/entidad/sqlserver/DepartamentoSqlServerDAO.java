package co.edu.uco.libreriauco.dao.datos.entidad.sqlserver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import co.edu.uco.libreriauco.dao.datos.entidad.DepartamentoDAO;
import co.edu.uco.libreriauco.dao.datos.entidad.SqlDAO;
import co.edu.uco.libreriauco.entidad.DepartamentoEntidad;
import co.edu.uco.libreriauco.entidad.PaisEntidad;
import co.edu.uco.libreriauco.transversal.catalogo.CatalogoMensajes;
import co.edu.uco.libreriauco.transversal.excepciones.LibreriaUCODatosException;
import co.edu.uco.libreriauco.transversal.utilitarios.UtilObjeto;
import co.edu.uco.libreriauco.transversal.utilitarios.UtilTexto;
import co.edu.uco.libreriauco.transversal.utilitarios.UtilUUID;

public class DepartamentoSqlServerDAO extends SqlDAO implements DepartamentoDAO {

	// Se une con pais para devolver cada departamento con la informacion de su pais
	private static final String SELECT_BASE = "SELECT d.id, d.nombre, p.id AS id_pais, p.nombre AS nombre_pais "
			+ "FROM departamento d INNER JOIN pais p ON p.id = d.pais";

	public DepartamentoSqlServerDAO(Connection conexion) {
		super(conexion);
	}

	@Override
	public DepartamentoEntidad consultarPorId(UUID id) {
		var sentenciaSql = SELECT_BASE + " WHERE d.id = ?";
		// Si no se encuentra el departamento se retorna uno con valores por defecto, nunca null
		var departamentoEncontrado = new DepartamentoEntidad.Builder().Build();

		try (var sentencia = getConnection().prepareStatement(sentenciaSql)) {
			sentencia.setString(1, UtilUUID.obtenerValorDefecto(id).toString());

			try (var resultado = sentencia.executeQuery()) {
				if (resultado.next()) {
					departamentoEncontrado = mapear(resultado);
				}
			}
		} catch (SQLException excepcion) {
			var mensajeUsuario = CatalogoMensajes.DepartamentoSqlServerDAO.USUARIO_ERROR_PROBLEMA_CONSULTANDO_DEPARTAMENTO_POR_ID;
			throw LibreriaUCODatosException.crear(mensajeUsuario, excepcion.getMessage(), excepcion);
		} catch (Exception excepcion) {
			var mensajeUsuario = CatalogoMensajes.DepartamentoSqlServerDAO.USUARIO_ERROR_PROBLEMA_NO_CONTROLADO_CONSULTANDO_DEPARTAMENTO_POR_ID;
			throw LibreriaUCODatosException.crear(mensajeUsuario, excepcion.getMessage(), excepcion);
		}

		return departamentoEncontrado;
	}

	@Override
	public List<DepartamentoEntidad> consultarPorFiltro(DepartamentoEntidad filtro) {
		// Solo se filtra por los campos que traen valor; un filtro vacio trae todos los departamentos
		var filtroSeguro = UtilObjeto.obtenerValorDefectoSiNulo(filtro, new DepartamentoEntidad.Builder().Build());
		var sentenciaSql = new StringBuilder(SELECT_BASE).append(" WHERE 1 = 1");
		var parametros = new ArrayList<String>();

		if (!UtilUUID.UUID_DEFECTO.equals(filtroSeguro.getId())) {
			sentenciaSql.append(" AND d.id = ?");
			parametros.add(filtroSeguro.getId().toString());
		}
		if (!UtilTexto.getUtilTexto().esVacia(filtroSeguro.getNombre())) {
			sentenciaSql.append(" AND d.nombre = ?");
			parametros.add(filtroSeguro.getNombre());
		}
		if (!UtilUUID.UUID_DEFECTO.equals(filtroSeguro.getPais().getId())) {
			sentenciaSql.append(" AND p.id = ?");
			parametros.add(filtroSeguro.getPais().getId().toString());
		}
		sentenciaSql.append(" ORDER BY d.nombre");

		try (var sentencia = getConnection().prepareStatement(sentenciaSql.toString())) {
			for (var indice = 0; indice < parametros.size(); indice++) {
				sentencia.setString(indice + 1, parametros.get(indice));
			}
			return ejecutarConsulta(sentencia.executeQuery());
		} catch (SQLException excepcion) {
			var mensajeUsuario = CatalogoMensajes.DepartamentoSqlServerDAO.USUARIO_ERROR_PROBLEMA_CONSULTANDO_DEPARTAMENTOS_POR_FILTRO;
			throw LibreriaUCODatosException.crear(mensajeUsuario, excepcion.getMessage(), excepcion);
		} catch (Exception excepcion) {
			var mensajeUsuario = CatalogoMensajes.DepartamentoSqlServerDAO.USUARIO_ERROR_PROBLEMA_NO_CONTROLADO_CONSULTANDO_DEPARTAMENTOS_POR_FILTRO;
			throw LibreriaUCODatosException.crear(mensajeUsuario, excepcion.getMessage(), excepcion);
		}
	}

	@Override
	public List<DepartamentoEntidad> consultarTodos() {
		var sentenciaSql = SELECT_BASE + " ORDER BY d.nombre";

		try (var sentencia = getConnection().prepareStatement(sentenciaSql)) {
			return ejecutarConsulta(sentencia.executeQuery());
		} catch (SQLException excepcion) {
			var mensajeUsuario = CatalogoMensajes.DepartamentoSqlServerDAO.USUARIO_ERROR_PROBLEMA_CONSULTANDO_TODOS_LOS_DEPARTAMENTOS;
			throw LibreriaUCODatosException.crear(mensajeUsuario, excepcion.getMessage(), excepcion);
		} catch (Exception excepcion) {
			var mensajeUsuario = CatalogoMensajes.DepartamentoSqlServerDAO.USUARIO_ERROR_PROBLEMA_NO_CONTROLADO_CONSULTANDO_TODOS_LOS_DEPARTAMENTOS;
			throw LibreriaUCODatosException.crear(mensajeUsuario, excepcion.getMessage(), excepcion);
		}
	}

	private List<DepartamentoEntidad> ejecutarConsulta(ResultSet resultado) throws SQLException {
		var departamentos = new ArrayList<DepartamentoEntidad>();

		try (resultado) {
			while (resultado.next()) {
				departamentos.add(mapear(resultado));
			}
		}

		return departamentos;
	}

	private DepartamentoEntidad mapear(ResultSet resultado) throws SQLException {
		var pais = new PaisEntidad.Builder()
				.id(UUID.fromString(resultado.getString("id_pais")))
				.nombre(resultado.getString("nombre_pais"))
				.Build();

		return new DepartamentoEntidad.Builder()
				.id(UUID.fromString(resultado.getString("id")))
				.nombre(resultado.getString("nombre"))
				.pais(pais)
				.Build();
	}

}
